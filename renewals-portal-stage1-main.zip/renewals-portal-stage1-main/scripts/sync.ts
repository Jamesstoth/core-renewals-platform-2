/**
 * Local sync script: Salesforce MCP → Supabase
 *
 * Usage:  npx tsx scripts/sync.ts
 */

import { readFileSync } from "fs";
import { resolve } from "path";

// Load .env.local before importing sync lib
function loadEnv() {
  try {
    const envPath = resolve(__dirname, "..", ".env.local");
    const content = readFileSync(envPath, "utf-8");
    for (const line of content.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      const value = trimmed.slice(eqIdx + 1).trim();
      if (!process.env[key]) process.env[key] = value;
    }
  } catch {
    // .env.local may not exist
  }
}

loadEnv();

// Use relative import — can't use @/ aliases in tsx scripts
import { runSync } from "../lib/sync";

async function main() {
  const mcpToken = process.env.SALESFORCE_MCP_TOKEN;
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY;

  if (!mcpToken) throw new Error("SALESFORCE_MCP_TOKEN not set");
  if (!supabaseUrl || !supabaseKey) throw new Error("SUPABASE_URL and SUPABASE_SERVICE_KEY must be set");

  console.log("Starting Salesforce → Supabase sync...");
  const result = await runSync(mcpToken, supabaseUrl, supabaseKey);
  console.log("Done:", result);
}

main().catch((err) => {
  console.error("Sync failed:", err);
  process.exit(1);
});
