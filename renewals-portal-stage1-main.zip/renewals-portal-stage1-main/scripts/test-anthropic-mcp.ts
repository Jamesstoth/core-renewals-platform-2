/**
 * Test script: Anthropic API → remote Salesforce MCP server
 *
 * Verifies that Claude can reach the Salesforce MCP server
 * (passed as a tool source via MCP connector) and execute sf_query.
 *
 * Usage:  npx tsx scripts/test-anthropic-mcp.ts
 */

import Anthropic from "@anthropic-ai/sdk";
import dotenv from "dotenv";
import path from "path";

dotenv.config({ path: path.resolve(__dirname, "../.env.local") });

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const SALESFORCE_MCP_TOKEN = process.env.SALESFORCE_MCP_TOKEN;
const MCP_SERVER_URL = "https://mcp.csaiautomations.com/salesforce/mcp/";

if (!ANTHROPIC_API_KEY || ANTHROPIC_API_KEY === "your-anthropic-api-key") {
  console.error("ERROR: Set ANTHROPIC_API_KEY in .env.local");
  process.exit(1);
}
if (!SALESFORCE_MCP_TOKEN) {
  console.error("ERROR: Set SALESFORCE_MCP_TOKEN in .env.local");
  process.exit(1);
}

async function main() {
  const client = new Anthropic({ apiKey: ANTHROPIC_API_KEY });

  console.log("Calling Anthropic API with remote MCP server...");
  console.log(`  MCP URL : ${MCP_SERVER_URL}`);
  console.log();

  const response = await (client.beta.messages.create as any)({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1024,
    betas: ["mcp-client-2025-11-20"],
    mcp_servers: [
      {
        type: "url",
        url: MCP_SERVER_URL,
        name: "salesforce",
        authorization_token: SALESFORCE_MCP_TOKEN,
      },
    ],
    tools: [
      {
        type: "mcp_toolset",
        mcp_server_name: "salesforce",
      },
    ],
    messages: [
      {
        role: "user",
        content:
          "Use the sf_query tool to run this exact SOQL query and return the results:\n" +
          "SELECT Id, Name, StageName, Renewal_Date__c, ARR_in_USD__c FROM Opportunity WHERE Type = 'Renewal' LIMIT 3",
      },
    ],
  });

  console.log("=== Response ===");
  console.log(`Stop reason: ${response.stop_reason}`);
  console.log();

  for (const block of response.content) {
    switch (block.type) {
      case "text":
        console.log("[Text]", block.text);
        break;

      case "mcp_tool_use":
        console.log(
          `[MCP Tool Call] ${block.name} (server: ${block.server_name})`
        );
        console.log("  Input:", JSON.stringify(block.input, null, 2));
        break;

      case "mcp_tool_result":
        console.log(`[MCP Tool Result] error=${block.is_error ?? false}`);
        if (Array.isArray(block.content)) {
          for (const item of block.content) {
            if (item.type === "text") {
              console.log("  Data:", item.text);
            } else {
              console.log("  Data:", JSON.stringify(item));
            }
          }
        } else {
          console.log("  Data:", JSON.stringify(block.content, null, 2));
        }
        break;

      case "tool_use":
        console.log(`[Tool Call] ${block.name}`);
        console.log("  Input:", JSON.stringify(block.input, null, 2));
        break;

      default:
        console.log(`[${block.type}]`, JSON.stringify(block, null, 2));
    }
    console.log();
  }
}

main().catch((err) => {
  console.error("Fatal error:", err.message ?? err);
  if (err.status) console.error("HTTP status:", err.status);
  if (err.error)
    console.error("API error:", JSON.stringify(err.error, null, 2));
  process.exit(1);
});
