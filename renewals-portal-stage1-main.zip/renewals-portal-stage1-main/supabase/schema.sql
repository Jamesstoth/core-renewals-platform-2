-- Renewals portal: opportunities table
-- Stores synced Salesforce opportunity data with rules engine results.
-- Populated by scripts/sync.ts running locally against the Salesforce MCP.

CREATE TABLE IF NOT EXISTS opportunities (
  -- Salesforce IDs
  sf_opportunity_id     TEXT PRIMARY KEY,
  sf_account_id         TEXT,

  -- Core fields
  opportunity_name      TEXT NOT NULL,
  account_name          TEXT NOT NULL,
  owner_name            TEXT NOT NULL,
  stage                 TEXT NOT NULL,
  renewal_date          DATE,
  close_date            DATE NOT NULL,
  arr                   NUMERIC DEFAULT 0,
  amount                NUMERIC DEFAULT 0,
  next_step             TEXT,
  description           TEXT,
  product_family        TEXT,

  -- Salesforce flags
  is_closed             BOOLEAN DEFAULT FALSE,
  is_won                BOOLEAN DEFAULT FALSE,
  has_open_activity     BOOLEAN DEFAULT FALSE,
  has_overdue_task      BOOLEAN DEFAULT FALSE,
  health_score          NUMERIC,
  churn_risk_category   TEXT,
  last_activity_date    DATE,

  -- Rules engine output
  queue_status          TEXT NOT NULL,
  flag_reason           TEXT NOT NULL,
  days_since_renewal_call INTEGER DEFAULT 0,
  last_contact_date     TEXT,
  renewal_call_logged   BOOLEAN DEFAULT FALSE,

  -- Activity history (last 5 entries as JSON array)
  activity_history      JSONB DEFAULT '[]'::JSONB,

  -- Sync metadata
  synced_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Indexes for common filter queries
  CONSTRAINT valid_queue_status CHECK (queue_status IN (
    'overdue_follow_up',
    'needs_follow_up_this_week',
    'recently_contacted',
    'waiting_on_customer',
    'waiting_on_internal_action',
    'no_action_needed',
    'needs_rep_review'
  ))
);

-- Indexes for filter/sort queries the frontend uses
CREATE INDEX IF NOT EXISTS idx_opp_owner ON opportunities (owner_name);
CREATE INDEX IF NOT EXISTS idx_opp_status ON opportunities (queue_status);
CREATE INDEX IF NOT EXISTS idx_opp_close_date ON opportunities (close_date);
CREATE INDEX IF NOT EXISTS idx_opp_stage ON opportunities (stage);
CREATE INDEX IF NOT EXISTS idx_opp_is_closed ON opportunities (is_closed);
