"use client";

import { useState, useMemo, useEffect, useCallback } from "react";
import {
  QueueStatus,
  QueueItem,
  MetricCard,
  FilterState,
  FilterOptions,
  SortConfig,
  ArrRange,
  HealthScoreBucket,
} from "@/types/renewals";
import TopBar from "@/components/TopBar";
import MetricCards from "@/components/MetricCards";
import FilterBar, { DEFAULT_FILTERS, DEFAULT_SORT } from "@/components/FilterBar";
import QueueList from "@/components/QueueList";

// ---------------------------------------------------------------------------
// Filter logic — all filters AND together
// ---------------------------------------------------------------------------

function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function matchesArrRange(arr: number, range: ArrRange): boolean {
  switch (range) {
    case "under_50k": return arr < 50000;
    case "50k_200k": return arr >= 50000 && arr < 200000;
    case "200k_500k": return arr >= 200000 && arr < 500000;
    case "over_500k": return arr >= 500000;
  }
}

function matchesHealthBucket(score: number | null, bucket: HealthScoreBucket): boolean {
  if (score === null) return false;
  switch (bucket) {
    case "at_risk": return score < 40;
    case "needs_attention": return score >= 40 && score < 70;
    case "healthy": return score >= 70;
  }
}

function applyFiltersAndSort(
  items: QueueItem[],
  filters: FilterState,
  sort: SortConfig
): QueueItem[] {
  let result = items;

  if (filters.owners.length > 0) {
    result = result.filter((i) => filters.owners.includes(i.opportunity.owner));
  }

  if (filters.followUpStatuses.length > 0) {
    result = result.filter((i) =>
      filters.followUpStatuses.includes(i.opportunity.queueStatus)
    );
  }

  if (filters.renewalCallLogged === "yes") {
    result = result.filter((i) => i.opportunity.renewalCallLogged);
  } else if (filters.renewalCallLogged === "no") {
    result = result.filter((i) => !i.opportunity.renewalCallLogged);
  }

  if (filters.closeDateRange) {
    const now = new Date();
    let start: Date;
    let end: Date;
    switch (filters.closeDateRange) {
      case "this_month":
        start = new Date(now.getFullYear(), now.getMonth(), 1);
        end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      case "next_30":
        start = now;
        end = addDays(now, 30);
        break;
      case "next_60":
        start = now;
        end = addDays(now, 60);
        break;
      case "next_90":
        start = now;
        end = addDays(now, 90);
        break;
      case "custom":
        start = filters.closeDateCustomStart
          ? new Date(filters.closeDateCustomStart)
          : new Date(0);
        end = filters.closeDateCustomEnd
          ? new Date(filters.closeDateCustomEnd)
          : new Date(9999, 0);
        break;
    }
    result = result.filter((i) => {
      const d = new Date(i.opportunity.closeDate);
      return d >= start && d <= end;
    });
  }

  if (filters.productFamilies.length > 0) {
    result = result.filter(
      (i) =>
        i.opportunity.productFamily !== null &&
        filters.productFamilies.includes(i.opportunity.productFamily)
    );
  }

  if (filters.stages.length > 0) {
    result = result.filter((i) =>
      filters.stages.includes(i.opportunity.stage)
    );
  }

  if (filters.arrRanges.length > 0) {
    result = result.filter((i) =>
      filters.arrRanges.some((r) => matchesArrRange(i.opportunity.arr, r))
    );
  }

  if (filters.healthScores.length > 0) {
    result = result.filter((i) =>
      filters.healthScores.some((b) =>
        matchesHealthBucket(i.opportunity.healthScore, b)
      )
    );
  }

  if (filters.churnRiskCategories.length > 0) {
    result = result.filter(
      (i) =>
        i.opportunity.churnRiskCategory !== null &&
        filters.churnRiskCategories.includes(i.opportunity.churnRiskCategory)
    );
  }

  // Sort
  const sorted = [...result];
  sorted.sort((a, b) => {
    const dir = sort.direction === "asc" ? 1 : -1;
    const oppA = a.opportunity;
    const oppB = b.opportunity;
    switch (sort.field) {
      case "closeDate":
        return dir * oppA.closeDate.localeCompare(oppB.closeDate);
      case "arr":
        return dir * (oppA.arr - oppB.arr);
      case "daysOverdue":
        return dir * (oppB.daysSinceLastRenewalCall - oppA.daysSinceLastRenewalCall);
      case "lastActivityDate":
        return dir * oppA.lastContactDate.localeCompare(oppB.lastContactDate);
    }
  });

  return sorted;
}

// ---------------------------------------------------------------------------
// Metrics
// ---------------------------------------------------------------------------

function computeMetrics(items: QueueItem[]): MetricCard[] {
  const overdueItems = items.filter(
    (i) => i.opportunity.queueStatus === QueueStatus.OverdueFollowUp
  );
  const dueThisWeek = items.filter(
    (i) => i.opportunity.queueStatus === QueueStatus.NeedsFollowUpThisWeek
  );

  return [
    {
      label: "Total Open Renewals",
      value: items.length,
      color: "border-blue-500",
      description: "All open renewal & upsell opportunities",
    },
    {
      label: "ARR at Risk",
      value: overdueItems.reduce((sum, i) => sum + i.opportunity.arr, 0),
      color: "border-red-500",
      description: "Sum of ARR for overdue opportunities",
      format: "currency",
    },
    {
      label: "Overdue Follow-Ups",
      value: overdueItems.length,
      color: "border-amber-500",
      description: "No contact in 14+ days",
    },
    {
      label: "Due This Week",
      value: dueThisWeek.length,
      color: "border-green-500",
      description: "7–14 days since last contact",
    },
  ];
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function Home() {
  const [items, setItems] = useState<QueueItem[]>([]);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    owners: [],
    stages: [],
    productFamilies: [],
    churnRiskCategories: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [sort, setSort] = useState<SortConfig>(DEFAULT_SORT);
  const [syncedAt, setSyncedAt] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/opportunities");
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? `Failed to fetch opportunities (${res.status})`);
        setItems(data.items ?? []);
      } else {
        setItems(data.items ?? []);
        setFilterOptions(
          data.filterOptions ?? {
            owners: [],
            stages: [],
            productFamilies: [],
            churnRiskCategories: [],
          }
        );
        if (data.syncedAt) setSyncedAt(data.syncedAt);
      }
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Failed to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const metrics = useMemo(() => computeMetrics(items), [items]);

  const displayedItems = useMemo(
    () => applyFiltersAndSort(items, filters, sort),
    [items, filters, sort]
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
        <TopBar
          onRefresh={fetchData}
          syncedAt={syncedAt}
          totalCount={items.length}
        />

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-4">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-gray-300 border-t-blue-600" />
            <p className="text-sm text-gray-500">
              Loading opportunities from Salesforce...
            </p>
          </div>
        ) : error ? (
          <div className="rounded-xl border border-red-200 bg-red-50 p-6">
            <h3 className="text-sm font-semibold text-red-900 mb-1">
              Failed to load opportunities
            </h3>
            <p className="text-sm text-red-700 mb-4">{error}</p>
            <button
              onClick={fetchData}
              className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 transition-colors"
            >
              Retry
            </button>
          </div>
        ) : (
          <>
            <MetricCards metrics={metrics} />
            <FilterBar
              filters={filters}
              onFiltersChange={setFilters}
              sort={sort}
              onSortChange={setSort}
              filterOptions={filterOptions}
              resultCount={displayedItems.length}
            />
            <QueueList items={displayedItems} />
          </>
        )}
      </div>
    </div>
  );
}
