"use client";

import {
  FilterState,
  FilterOptions,
  SortConfig,
  SortField,
  QueueStatus,
  CloseDateRange,
  ArrRange,
  HealthScoreBucket,
} from "@/types/renewals";
import { getStatusConfig, cn } from "@/lib/utils";
import MultiSelectDropdown from "./MultiSelectDropdown";

interface FilterBarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  sort: SortConfig;
  onSortChange: (sort: SortConfig) => void;
  filterOptions: FilterOptions;
  resultCount: number;
}

const STATUS_OPTIONS = Object.values(QueueStatus).map((s) => ({
  value: s,
  label: getStatusConfig(s).label,
}));

const CLOSE_DATE_OPTIONS: { value: CloseDateRange; label: string }[] = [
  { value: "this_month", label: "This month" },
  { value: "next_30", label: "Next 30 days" },
  { value: "next_60", label: "Next 60 days" },
  { value: "next_90", label: "Next 90 days" },
  { value: "custom", label: "Custom range" },
];

const ARR_OPTIONS: { value: ArrRange; label: string }[] = [
  { value: "under_50k", label: "Under $50k" },
  { value: "50k_200k", label: "$50k – $200k" },
  { value: "200k_500k", label: "$200k – $500k" },
  { value: "over_500k", label: "Over $500k" },
];

const HEALTH_OPTIONS: { value: HealthScoreBucket; label: string }[] = [
  { value: "at_risk", label: "At risk (< 40%)" },
  { value: "needs_attention", label: "Needs attention (40–70%)" },
  { value: "healthy", label: "Healthy (> 70%)" },
];

const SORT_OPTIONS: { value: SortField; label: string }[] = [
  { value: "closeDate", label: "Close date" },
  { value: "arr", label: "ARR value" },
  { value: "daysOverdue", label: "Days overdue" },
  { value: "lastActivityDate", label: "Last activity" },
];

const RENEWAL_CALL_OPTIONS = [
  { value: "all", label: "All" },
  { value: "yes", label: "Yes" },
  { value: "no", label: "No" },
] as const;

function update(
  filters: FilterState,
  patch: Partial<FilterState>
): FilterState {
  return { ...filters, ...patch };
}

function hasActiveFilters(filters: FilterState): boolean {
  return (
    filters.owners.length > 0 ||
    filters.followUpStatuses.length > 0 ||
    filters.renewalCallLogged !== "all" ||
    filters.closeDateRange !== null ||
    filters.productFamilies.length > 0 ||
    filters.stages.length > 0 ||
    filters.arrRanges.length > 0 ||
    filters.healthScores.length > 0 ||
    filters.churnRiskCategories.length > 0
  );
}

export const DEFAULT_FILTERS: FilterState = {
  owners: [],
  followUpStatuses: [],
  renewalCallLogged: "all",
  closeDateRange: null,
  closeDateCustomStart: null,
  closeDateCustomEnd: null,
  productFamilies: [],
  stages: [],
  arrRanges: [],
  healthScores: [],
  churnRiskCategories: [],
};

export const DEFAULT_SORT: SortConfig = {
  field: "closeDate",
  direction: "asc",
};

export default function FilterBar({
  filters,
  onFiltersChange,
  sort,
  onSortChange,
  filterOptions,
  resultCount,
}: FilterBarProps) {
  const active = hasActiveFilters(filters);

  return (
    <div className="bg-white border border-gray-200 rounded-xl px-5 py-4 space-y-3">
      {/* Row 1: Primary filters */}
      <div className="flex flex-wrap items-center gap-2">
        <MultiSelectDropdown
          label="Rep / Owner"
          options={filterOptions.owners.map((o) => ({ value: o, label: o }))}
          selected={filters.owners}
          onChange={(v) => onFiltersChange(update(filters, { owners: v }))}
        />
        <MultiSelectDropdown
          label="Follow-up Status"
          options={STATUS_OPTIONS}
          selected={filters.followUpStatuses}
          onChange={(v) =>
            onFiltersChange(
              update(filters, { followUpStatuses: v as QueueStatus[] })
            )
          }
        />

        {/* Renewal call toggle */}
        <div className="inline-flex items-center rounded-lg border border-gray-300 overflow-hidden">
          <span className="px-2.5 py-1.5 text-xs font-medium text-gray-500 bg-gray-50 border-r border-gray-300">
            Renewal call
          </span>
          {RENEWAL_CALL_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() =>
                onFiltersChange(
                  update(filters, {
                    renewalCallLogged: opt.value as FilterState["renewalCallLogged"],
                  })
                )
              }
              className={cn(
                "px-2.5 py-1.5 text-xs font-medium transition-colors",
                filters.renewalCallLogged === opt.value
                  ? "bg-gray-900 text-white"
                  : "text-gray-600 hover:bg-gray-50"
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Close date range */}
        <select
          value={filters.closeDateRange ?? ""}
          onChange={(e) =>
            onFiltersChange(
              update(filters, {
                closeDateRange: (e.target.value || null) as CloseDateRange | null,
                closeDateCustomStart:
                  e.target.value !== "custom"
                    ? null
                    : filters.closeDateCustomStart,
                closeDateCustomEnd:
                  e.target.value !== "custom"
                    ? null
                    : filters.closeDateCustomEnd,
              })
            )
          }
          className={cn(
            "rounded-lg border px-3 py-1.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500",
            filters.closeDateRange
              ? "bg-blue-50 border-blue-300 text-blue-800"
              : "bg-white border-gray-300 text-gray-700"
          )}
        >
          <option value="">Close date: All</option>
          {CLOSE_DATE_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>

        {filters.closeDateRange === "custom" && (
          <>
            <input
              type="date"
              value={filters.closeDateCustomStart ?? ""}
              onChange={(e) =>
                onFiltersChange(
                  update(filters, { closeDateCustomStart: e.target.value || null })
                )
              }
              className="rounded-lg border border-gray-300 px-2 py-1.5 text-sm"
            />
            <span className="text-xs text-gray-400">to</span>
            <input
              type="date"
              value={filters.closeDateCustomEnd ?? ""}
              onChange={(e) =>
                onFiltersChange(
                  update(filters, { closeDateCustomEnd: e.target.value || null })
                )
              }
              className="rounded-lg border border-gray-300 px-2 py-1.5 text-sm"
            />
          </>
        )}

        <MultiSelectDropdown
          label="Stage"
          options={filterOptions.stages.map((s) => ({ value: s, label: s }))}
          selected={filters.stages}
          onChange={(v) => onFiltersChange(update(filters, { stages: v }))}
        />
      </div>

      {/* Row 2: Secondary filters + sort */}
      <div className="flex flex-wrap items-center gap-2">
        {filterOptions.productFamilies.length > 0 && (
          <MultiSelectDropdown
            label="Product"
            options={filterOptions.productFamilies.map((p) => ({
              value: p,
              label: p,
            }))}
            selected={filters.productFamilies}
            onChange={(v) =>
              onFiltersChange(update(filters, { productFamilies: v }))
            }
          />
        )}

        <MultiSelectDropdown
          label="ARR Range"
          options={ARR_OPTIONS}
          selected={filters.arrRanges}
          onChange={(v) =>
            onFiltersChange(update(filters, { arrRanges: v as ArrRange[] }))
          }
        />

        <MultiSelectDropdown
          label="Health Score"
          options={HEALTH_OPTIONS}
          selected={filters.healthScores}
          onChange={(v) =>
            onFiltersChange(
              update(filters, { healthScores: v as HealthScoreBucket[] })
            )
          }
        />

        {filterOptions.churnRiskCategories.length > 0 && (
          <MultiSelectDropdown
            label="Churn Risk"
            options={filterOptions.churnRiskCategories.map((c) => ({
              value: c,
              label: c,
            }))}
            selected={filters.churnRiskCategories}
            onChange={(v) =>
              onFiltersChange(update(filters, { churnRiskCategories: v }))
            }
          />
        )}

        {/* Sort controls — pushed right */}
        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-gray-400">Sort by</span>
          <select
            value={sort.field}
            onChange={(e) =>
              onSortChange({ ...sort, field: e.target.value as SortField })
            }
            className="rounded-lg border border-gray-300 bg-white px-2 py-1.5 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <button
            onClick={() =>
              onSortChange({
                ...sort,
                direction: sort.direction === "asc" ? "desc" : "asc",
              })
            }
            className="rounded-lg border border-gray-300 bg-white p-1.5 text-gray-500 hover:bg-gray-50 transition-colors"
            title={sort.direction === "asc" ? "Ascending" : "Descending"}
          >
            <svg
              className={cn(
                "h-4 w-4 transition-transform",
                sort.direction === "desc" && "rotate-180"
              )}
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={2}
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M3 4.5h14.25M3 9h9.75M3 13.5h5.25m5.25-.75L17.25 9m0 0L21 12.75M17.25 9v12"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* Active filters summary + clear */}
      {active && (
        <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
          <span className="text-xs text-gray-500">
            {resultCount} result{resultCount !== 1 ? "s" : ""}
          </span>
          <button
            onClick={() => onFiltersChange(DEFAULT_FILTERS)}
            className="text-xs font-medium text-red-600 hover:text-red-800 ml-2"
          >
            Clear all filters
          </button>
        </div>
      )}
    </div>
  );
}
