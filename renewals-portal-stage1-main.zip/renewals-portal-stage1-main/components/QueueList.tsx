"use client";

import Link from "next/link";
import { QueueItem } from "@/types/renewals";
import { getStatusConfig, formatDate, formatCurrency, cn } from "@/lib/utils";

interface QueueListProps {
  items: QueueItem[];
}

export default function QueueList({ items }: QueueListProps) {
  if (items.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
        <p className="text-gray-500 text-sm">
          No opportunities match the current filters.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const { opportunity } = item;
        const status = getStatusConfig(opportunity.queueStatus);

        return (
          <Link
            key={opportunity.id}
            href={`/opportunity/${opportunity.id}`}
            className={cn(
              "block bg-white border border-gray-200 rounded-xl hover:shadow-md hover:border-gray-300 transition-all"
            )}
          >
            <div className="px-6 py-4 flex items-center gap-4">
              {/* Status pill */}
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium whitespace-nowrap",
                  status.bgColor,
                  status.textColor
                )}
              >
                <span
                  className={cn("h-1.5 w-1.5 rounded-full", status.dotColor)}
                />
                {status.label}
              </span>

              {/* Account & opportunity name */}
              <div className="flex-1 min-w-0">
                <span className="font-semibold text-gray-900">
                  {opportunity.accountName}
                </span>
                <span className="text-gray-400 mx-1.5">·</span>
                <span className="text-sm text-gray-600 truncate">
                  {opportunity.opportunityName}
                </span>
              </div>

              {/* Metadata */}
              <div className="flex items-center gap-4 text-sm text-gray-500 shrink-0">
                <span className="hidden lg:inline">
                  {formatCurrency(opportunity.arr)}
                </span>
                <span>{opportunity.owner}</span>
                <span className="hidden xl:inline">{opportunity.stage}</span>
                <span className="hidden xl:inline">
                  {formatDate(opportunity.renewalDate)}
                </span>
                <span className="inline-flex items-center rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
                  {opportunity.daysSinceLastRenewalCall}d since activity
                </span>
                {/* Arrow icon */}
                <svg
                  className="h-5 w-5 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="m8.25 4.5 7.5 7.5-7.5 7.5"
                  />
                </svg>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
