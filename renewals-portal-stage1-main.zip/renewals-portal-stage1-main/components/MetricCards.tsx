import { MetricCard } from "@/types/renewals";
import { formatCurrency } from "@/lib/utils";

interface MetricCardsProps {
  metrics: MetricCard[];
}

export default function MetricCards({ metrics }: MetricCardsProps) {
  return (
    <div className="grid grid-cols-4 gap-4">
      {metrics.map((metric) => (
        <div
          key={metric.label}
          className={`bg-white rounded-xl border border-gray-200 p-5 border-l-4 ${metric.color}`}
        >
          <p className="text-3xl font-bold text-gray-900">
            {metric.format === "currency"
              ? formatCurrency(metric.value)
              : metric.value.toLocaleString()}
          </p>
          <p className="text-sm font-medium text-gray-700 mt-1">
            {metric.label}
          </p>
          <p className="text-xs text-gray-500 mt-0.5">{metric.description}</p>
        </div>
      ))}
    </div>
  );
}
