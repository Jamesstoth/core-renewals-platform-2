"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

interface TopBarProps {
  onRefresh: () => void;
  syncedAt: string | null;
  totalCount: number;
}

function formatSyncTime(syncedAt: string | null): string {
  if (!syncedAt) return "Never synced";
  const syncDate = new Date(syncedAt);
  const now = new Date();
  const diffMs = now.getTime() - syncDate.getTime();
  const diffMin = Math.floor(diffMs / 60000);

  if (diffMin < 1) return "Synced just now";
  if (diffMin < 60) return `Synced ${diffMin}m ago`;

  const diffHrs = Math.floor(diffMin / 60);
  if (diffHrs < 24) return `Synced ${diffHrs}h ago`;

  return `Synced ${syncDate.toLocaleDateString("en-US", { month: "short", day: "numeric" })} at ${syncDate.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`;
}

export default function TopBar({
  onRefresh,
  syncedAt,
  totalCount,
}: TopBarProps) {
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<string | null>(null);
  const syncLabel = formatSyncTime(syncedAt);
  const isStale = !syncedAt || (Date.now() - new Date(syncedAt).getTime()) > 2 * 60 * 60 * 1000; // >2hrs

  const handleSync = async () => {
    setSyncing(true);
    setSyncResult(null);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 65000);
    try {
      const res = await fetch("/api/sync-anthropic", {
        method: "POST",
        signal: controller.signal,
      });
      clearTimeout(timeout);
      const data = await res.json();
      if (!res.ok) {
        setSyncResult(`Sync failed: ${data.error ?? res.statusText}`);
      } else {
        setSyncResult(
          `Synced ${data.opportunities} opportunities in ${(data.durationMs / 1000).toFixed(1)}s`
        );
        onRefresh();
      }
    } catch (err) {
      clearTimeout(timeout);
      if (err instanceof DOMException && err.name === "AbortError") {
        setSyncResult(
          "Sync took too long — try again or wait for the nightly auto-sync"
        );
      } else {
        setSyncResult(
          `Sync failed: ${err instanceof Error ? err.message : "Network error"}`
        );
      }
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-6 py-4">
      <div>
        <h1 className="text-xl font-semibold text-gray-900">
          Renewals Platform
        </h1>
        <p className="text-sm text-gray-500 mt-0.5">
          Your AI-powered renewals command centre
        </p>
      </div>
      <div className="flex items-center gap-3">
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium",
            isStale
              ? "bg-amber-50 border-amber-200 text-amber-700"
              : "bg-green-50 border-green-200 text-green-700"
          )}
        >
          <span
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              isStale ? "bg-amber-500" : "bg-green-500"
            )}
          />
          {syncLabel}
        </span>
        <button
          onClick={onRefresh}
          className="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <svg
            className="h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99"
            />
          </svg>
          Refresh
        </button>
        <div className="relative">
          <button
            onClick={handleSync}
            disabled={syncing}
            className={cn(
              "inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white transition-colors",
              syncing
                ? "bg-blue-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700"
            )}
          >
            {syncing ? (
              <>
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                Syncing...
              </>
            ) : (
              <>
                <svg
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 16.5V9.75m0 0 3 3m-3-3-3 3M6.75 19.5a4.5 4.5 0 0 1-1.41-8.775 5.25 5.25 0 0 1 10.233-2.33 3 3 0 0 1 3.758 3.848A3.752 3.752 0 0 1 18 19.5H6.75Z"
                  />
                </svg>
                Sync Salesforce
              </>
            )}
          </button>
          {syncResult && (
            <div className="absolute right-0 top-full mt-2 w-80 rounded-lg border border-gray-200 bg-white p-4 shadow-lg z-50">
              <p className={cn(
                "text-sm",
                syncResult.startsWith("Sync failed") ? "text-red-700" : "text-green-700"
              )}>
                {syncResult}
              </p>
              <button
                onClick={() => setSyncResult(null)}
                className="mt-2 text-xs text-gray-400 hover:text-gray-600 transition-colors"
              >
                Dismiss
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
