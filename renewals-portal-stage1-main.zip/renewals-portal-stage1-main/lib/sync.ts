/**
 * Shared sync logic used by both scripts/sync.ts (local CLI) and
 * app/api/cron/sync/route.ts (Vercel cron / manual trigger).
 *
 * Extracted into lib/ so both entry points share the same code.
 * Does NOT use @/ path aliases — imported via relative paths from scripts/.
 */

import { createClient, SupabaseClient } from "@supabase/supabase-js";

// ---------------------------------------------------------------------------
// MCP client
// ---------------------------------------------------------------------------

const SALESFORCE_MCP_URL = "https://mcp.csaiautomations.com/salesforce/mcp/";

interface JsonRpcResponse {
  jsonrpc: string;
  id: number;
  result?: unknown;
  error?: { code: number; message: string };
}

function parseSSE(body: string): JsonRpcResponse | null {
  const lines = body.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  let lastData: string | null = null;
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith("data:")) {
      lastData = trimmed.slice(5).trim();
    }
  }
  if (!lastData) return null;
  return JSON.parse(lastData);
}

class McpClient {
  private sessionId: string | null = null;
  private counter = 0;
  private ready = false;
  private token: string;

  constructor(token: string) {
    this.token = token;
  }

  private url(): string {
    return `${SALESFORCE_MCP_URL}?token=${encodeURIComponent(this.token)}`;
  }

  private async post(method: string, params: Record<string, unknown>): Promise<JsonRpcResponse> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Accept: "application/json, text/event-stream",
    };
    if (this.sessionId) headers["Mcp-Session-Id"] = this.sessionId;

    const res = await fetch(this.url(), {
      method: "POST",
      headers,
      body: JSON.stringify({ jsonrpc: "2.0", id: ++this.counter, method, params }),
    });

    const sid = res.headers.get("Mcp-Session-Id");
    if (sid) this.sessionId = sid;

    const body = await res.text();
    if (!res.ok) throw new Error(`MCP ${method} failed (${res.status}): ${body.slice(0, 300)}`);

    const ct = res.headers.get("Content-Type") ?? "";
    if (ct.includes("text/event-stream")) {
      const parsed = parseSSE(body);
      if (!parsed) throw new Error(`MCP ${method}: empty SSE response`);
      return parsed;
    }
    return JSON.parse(body);
  }

  async init(): Promise<void> {
    if (this.ready) return;
    const res = await this.post("initialize", {
      protocolVersion: "2025-03-26",
      capabilities: {},
      clientInfo: { name: "renewals-sync", version: "1.0.0" },
    });
    if (res.error) throw new Error(`MCP init failed: ${res.error.message}`);

    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (this.sessionId) headers["Mcp-Session-Id"] = this.sessionId;
    await fetch(this.url(), {
      method: "POST",
      headers,
      body: JSON.stringify({ jsonrpc: "2.0", method: "notifications/initialized" }),
    }).catch(() => {});

    this.ready = true;
  }

  async sfQuery(soql: string): Promise<Record<string, unknown>[]> {
    await this.init();
    const res = await this.post("tools/call", { name: "sf_query", arguments: { soql } });
    if (res.error) throw new Error(`sf_query failed: ${res.error.message}`);

    const result = res.result as { content: { text: string }[] };
    const raw = result.content?.[0]?.text;
    if (!raw) throw new Error("sf_query returned empty response");

    let parsed: Record<string, unknown>;
    try {
      parsed = JSON.parse(raw);
    } catch {
      throw new Error(`sf_query returned non-JSON response: ${raw.slice(0, 300)}`);
    }

    if (parsed.content && Array.isArray(parsed.content) && (parsed.content as { text?: string }[])[0]?.text) {
      try {
        parsed = JSON.parse((parsed.content as { text: string }[])[0].text);
      } catch {
        throw new Error(`sf_query inner response is not valid JSON: ${(parsed.content as { text: string }[])[0].text.slice(0, 300)}`);
      }
    }
    return (parsed.records as Record<string, unknown>[]) ?? [];
  }
}

// ---------------------------------------------------------------------------
// SOQL queries
// ---------------------------------------------------------------------------

const OPP_QUERY = `
  SELECT Id, Name, AccountId, Account.Name, OwnerId, Owner.Name,
    StageName, Renewal_Date__c, CloseDate, ARR__c, Amount,
    LastActivityDate, Next_Follow_Up_Date__c, NextStep,
    IsClosed, IsWon, HasOpenActivity, HasOverdueTask,
    Health_Score__c, AI_Churn_Risk_Category__c, Priority_Score__c, Product__c
  FROM Opportunity
  WHERE IsClosed = false AND Type IN ('Renewal', 'Upsell')
  ORDER BY CloseDate ASC
  LIMIT 200
`;

const TASK_FIELDS =
  "Id, Subject, Status, Type, TaskSubtype, ActivityDate, CompletedDateTime, Description, Owner.Name, WhatId, Is_Renewal_Call__c, Work_Unit_Type__c, CallType, CallDurationInSeconds";

function renewalCallQuery(ids: string[]): string {
  return `SELECT ${TASK_FIELDS} FROM Task WHERE WhatId IN (${ids.map((i) => `'${i}'`).join(",")}) AND Is_Renewal_Call__c = true ORDER BY CompletedDateTime DESC`;
}

function followUpQuery(ids: string[]): string {
  return `SELECT ${TASK_FIELDS} FROM Task WHERE WhatId IN (${ids.map((i) => `'${i}'`).join(",")}) AND Type IN ('Call', 'Email') AND Status = 'Completed' ORDER BY CompletedDateTime DESC`;
}

// ---------------------------------------------------------------------------
// Rules engine
// ---------------------------------------------------------------------------

function daysBetween(dateStr: string, now: Date): number {
  return Math.floor((now.getTime() - new Date(dateStr).getTime()) / 86400000);
}

function mostRecentDate(tasks: Record<string, unknown>[]): string | null {
  let latest: string | null = null;
  for (const t of tasks) {
    const d = (t.CompletedDateTime ?? t.ActivityDate) as string | null;
    if (d && (!latest || d > latest)) latest = d;
  }
  return latest;
}

function evaluate(
  opp: Record<string, unknown>,
  renewalCalls: Record<string, unknown>[],
  followUps: Record<string, unknown>[],
  now: Date
) {
  if (opp.IsClosed) {
    return { status: "no_action_needed", reason: `Opportunity is ${opp.IsWon ? "Closed Won" : "Closed Lost"}.`, days: null, lastContact: null };
  }
  if (renewalCalls.length === 0) {
    return { status: "needs_rep_review", reason: "No renewal call logged. Not yet eligible for follow-up queue.", days: null, lastContact: null };
  }

  const rcDate = mostRecentDate(renewalCalls);
  const fuDate = mostRecentDate(followUps);
  const anchor = fuDate && fuDate > (rcDate ?? "") ? fuDate : rcDate;
  if (!anchor) {
    return { status: "needs_rep_review", reason: "Unable to determine last contact date.", days: null, lastContact: null };
  }

  const daysSince = daysBetween(anchor, now);
  const daysRc = rcDate ? daysBetween(rcDate, now) : null;

  if (daysSince < 7) {
    return { status: "recently_contacted", reason: `Last contact ${daysSince}d ago (${anchor.split("T")[0]}).`, days: daysRc, lastContact: anchor };
  }
  if (daysSince <= 14) {
    return { status: "needs_follow_up_this_week", reason: `${daysSince}d since last contact. Follow-up recommended.`, days: daysRc, lastContact: anchor };
  }
  return { status: "overdue_follow_up", reason: `${daysSince}d since last contact. Overdue.`, days: daysRc, lastContact: anchor };
}

// ---------------------------------------------------------------------------
// Public sync function
// ---------------------------------------------------------------------------

export interface SyncResult {
  opportunities: number;
  renewalCalls: number;
  followUps: number;
}

export async function runSync(
  mcpToken: string,
  supabaseUrl: string,
  supabaseKey: string,
  log: (msg: string) => void = console.log
): Promise<SyncResult> {
  const supabase: SupabaseClient = createClient(supabaseUrl, supabaseKey);
  const mcp = new McpClient(mcpToken);

  log("Fetching opportunities from Salesforce...");
  const opps = await mcp.sfQuery(OPP_QUERY);
  log(`Found ${opps.length} opportunities`);

  if (opps.length === 0) {
    log("No opportunities to sync.");
    return { opportunities: 0, renewalCalls: 0, followUps: 0 };
  }

  const oppIds = opps.map((o) => o.Id as string);

  log("Fetching tasks...");
  const allRenewalCalls: Record<string, unknown>[] = [];
  const allFollowUps: Record<string, unknown>[] = [];

  for (let i = 0; i < oppIds.length; i += 200) {
    const batch = oppIds.slice(i, i + 200);
    const [rc, fu] = await Promise.all([
      mcp.sfQuery(renewalCallQuery(batch)),
      mcp.sfQuery(followUpQuery(batch)),
    ]);
    allRenewalCalls.push(...rc);
    allFollowUps.push(...fu);
  }

  log(`Fetched ${allRenewalCalls.length} renewal calls, ${allFollowUps.length} follow-ups`);

  // Group by opportunity
  const rcByOpp = new Map<string, Record<string, unknown>[]>();
  for (const t of allRenewalCalls) {
    const wid = t.WhatId as string;
    rcByOpp.set(wid, [...(rcByOpp.get(wid) ?? []), t]);
  }
  const fuByOpp = new Map<string, Record<string, unknown>[]>();
  for (const t of allFollowUps) {
    const wid = t.WhatId as string;
    fuByOpp.set(wid, [...(fuByOpp.get(wid) ?? []), t]);
  }

  // Build rows
  const now = new Date();
  const rows = opps.map((opp) => {
    const rc = rcByOpp.get(opp.Id as string) ?? [];
    const fu = fuByOpp.get(opp.Id as string) ?? [];
    const rules = evaluate(opp, rc, fu, now);

    const allActivity = [...rc, ...fu];
    const seen = new Set<string>();
    const deduped = allActivity.filter((t) => {
      const id = t.Id as string;
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });
    deduped.sort((a, b) => {
      const da = ((a.CompletedDateTime ?? a.ActivityDate) as string) ?? "";
      const db = ((b.CompletedDateTime ?? b.ActivityDate) as string) ?? "";
      return db.localeCompare(da);
    });

    const typeMap: Record<string, string> = { Call: "Call", Email: "Email", Meeting: "Meeting" };
    const activityHistory = deduped.map((t) => {
      const notes = (t.Description as string) ?? "";
      return {
        id: t.Id,
        date: ((t.CompletedDateTime ?? t.ActivityDate) as string) ?? "",
        type: typeMap[(t.Type as string) ?? ""] ?? "Internal Note",
        subject: (t.Subject as string) ?? "(No subject)",
        performedBy: ((t.Owner as { Name?: string })?.Name) ?? "Unknown",
        notes: notes.length > 200 ? notes.slice(0, 200) + "..." : notes,
      };
    });

    const account = opp.Account as { Name?: string } | null;
    const owner = opp.Owner as { Name?: string } | null;

    return {
      sf_opportunity_id: opp.Id as string,
      sf_account_id: (opp.AccountId as string) ?? null,
      opportunity_name: opp.Name as string,
      account_name: account?.Name ?? "Unknown Account",
      owner_name: owner?.Name ?? "Unassigned",
      stage: opp.StageName as string,
      renewal_date: (opp.Renewal_Date__c as string) ?? null,
      close_date: opp.CloseDate as string,
      arr: (opp.ARR__c as number) ?? (opp.Amount as number) ?? 0,
      amount: (opp.Amount as number) ?? (opp.ARR__c as number) ?? 0,
      next_step: (opp.NextStep as string) ?? null,
      description: (opp.Description as string) ?? null,
      product_family: (opp.Product__c as string) ?? null,
      is_closed: (opp.IsClosed as boolean) ?? false,
      is_won: (opp.IsWon as boolean) ?? false,
      has_open_activity: (opp.HasOpenActivity as boolean) ?? false,
      has_overdue_task: (opp.HasOverdueTask as boolean) ?? false,
      health_score: (opp.Health_Score__c as number) ?? null,
      churn_risk_category: (opp.AI_Churn_Risk_Category__c as string) ?? null,
      last_activity_date: (opp.LastActivityDate as string) ?? null,
      queue_status: rules.status,
      flag_reason: rules.reason,
      days_since_renewal_call: rules.days ?? 0,
      last_contact_date: rules.lastContact ?? null,
      renewal_call_logged: rc.length > 0,
      activity_history: activityHistory,
      synced_at: now.toISOString(),
    };
  });

  log(`Upserting ${rows.length} rows into Supabase...`);
  const { error } = await supabase
    .from("opportunities")
    .upsert(rows, { onConflict: "sf_opportunity_id" });

  if (error) {
    throw new Error(`Supabase upsert failed: ${error.message}`);
  }

  // Mark opportunities no longer in the open set as closed so stale records
  // don't linger in the queue after being closed in Salesforce.
  const syncedIds = rows.map((r) => r.sf_opportunity_id);
  const { error: closeError, count: closedCount } = await supabase
    .from("opportunities")
    .update({
      is_closed: true,
      queue_status: "no_action_needed",
      flag_reason: "Closed in Salesforce (detected during sync).",
      synced_at: now.toISOString(),
    })
    .eq("is_closed", false)
    .not("sf_opportunity_id", "in", `(${syncedIds.join(",")})`);

  if (closeError) {
    log(`Warning: failed to close stale records: ${closeError.message}`);
  } else if (closedCount && closedCount > 0) {
    log(`Marked ${closedCount} stale opportunities as closed.`);
  }

  log(`Sync complete. ${rows.length} opportunities synced.`);
  return { opportunities: rows.length, renewalCalls: allRenewalCalls.length, followUps: allFollowUps.length };
}
